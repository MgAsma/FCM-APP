import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-time-list',
  templateUrl: './time-list.component.html',
  styleUrls: ['./time-list.component.scss'],
})
export class TimeListComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
