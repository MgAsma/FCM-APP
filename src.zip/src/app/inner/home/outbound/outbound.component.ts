import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outbound',
  templateUrl: './outbound.component.html',
  styleUrls: ['./outbound.component.scss'],
})
export class OutboundComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
