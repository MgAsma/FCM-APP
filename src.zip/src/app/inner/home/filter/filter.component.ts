import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-home',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss'],
})
export class FilterComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
