import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recurring-followup',
  templateUrl: './recurring-followup.component.html',
  styleUrls: ['./recurring-followup.component.scss'],
})
export class RecurringFollowupComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
