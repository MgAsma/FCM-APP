import { Component, OnInit } from '@angular/core';
import { ModalController, Platform } from '@ionic/angular';

import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { environment } from '../../../environments/environment';
import { AllocationEmittersService } from '../../service/allocation-emitters.service';
import { ApiService } from '../../service/api/api.service';
import { BaseServiceService } from '../../service/base-service.service';



@Component({
  selector: 'app-allocations',
  templateUrl: './allocations.page.html',
  styleUrls: ['./allocations.page.scss'],
})
export class AllocationsPage implements OnInit {
  searchBar: boolean = false;
  placeholderText = 'Search by Name/Status';
  data: any = [];
  leadCards: any;
  totalNumberOfRecords: any;
  currentPage: any;
  counselor: any = [];
  filteredData: any = [];
  filterByStatus: any = [];
  showError: boolean = false;
  searchTerm: any;

  

  constructor(
    private allocate: AllocationEmittersService,
    private modalController: ModalController,
    private baseService: BaseServiceService,
    private api: ApiService,
    private _baseService: BaseServiceService,
    private callNumber: CallNumber,
    private platform: Platform
  ) {
   
    
  }

 
  getStatus() {
    this._baseService.getData(environment.lead_status).subscribe(
      (res: any) => {
        if (res) {
          this.filterByStatus = res.results;
        }
      },
      (error: any) => {
        this.api.showToast(error.error.message);
      }
    );
  }
  ngOnInit() {

    this.getStatus();
    this.allocate.searchBar.subscribe((res) => {
      if (res === true) {
        this.searchBar = true;
      } else {
        this.searchBar = false;
      }
    });
    let query: any;
    this.allocate.filterStatus.subscribe(
      (res: any) => {
        if (res) {
          query = `?status=${res}`;
          this.getLeadlist(query);
        }
      },
      (error: any) => {
        this.api.showToast(error.error.error.message);
      }
    );

    query = `?page=1&page_size=10`;
    this.getLeadlist(query);
    this.getCounselor();
  }
  handleRefresh(event: any) {
    setTimeout(() => {
      this.leadCards = [];
      this.data = [];
      let query = `?page=1&page_size=10`;
      this.getLeadlist(query);
      event.target.complete();
    }, 2000);
  }

  getLeadlist(query:any){  
   this.baseService.getData(`${environment.lead_list}${query}`).subscribe((res: any) => {
     if (res.results) {
      this.leadCards = []
      this.data = []
       this.leadCards = res.results;
       this.data = new MatTableDataSource<any>(this.leadCards);
       this.totalNumberOfRecords = res.total_no_of_record
       
     }
   }, (error: any) => {
     this.api.showToast(error.error.message);
   });
   
  }
  onPageChange(event: any, dataSource: MatTableDataSource<any>, type?: any) {
    if (event) {
      this.currentPage = event.pageIndex + 1;
      let query: any;
      if(this.searchTerm){
        query = `?page=${this.currentPage}&page_size=${event.pageSize}&key=${this.searchTerm}`;
      }else{
        query = `?page=${this.currentPage}&page_size=${event.pageSize}`;
      }
     
      this.getLeadlist(query);
    }
  }

  callInitiated:boolean=false;
  callStartTime!: Date;
  callContact(number: string,id:any) {
    this.callStartTime = new Date();
    console.log(this.callStartTime, 'time');
    this.callNumber.callNumber(number, true).then(() => {
        this.callInitiated=true;
        // console.log('Dialer Launched!');
        // let data = {
        //   user:id,
        //   status:2
        // }
        // this.baseService.postData(`${environment.counsellor_status}`,data).subscribe((res:any)=>{
        //   if(res){
        //     this.api.showToast(res.message)  
        //   }
        // },((error:any)=>{
        //   this.api.showToast(error?.error?.message)
        // }))
      })
      .catch(() => {
        console.log('Error launching dialer');
      });
  }


  getCounselor() {
    this.baseService
      .getData(`${environment._user}/?role_name=counsellor`)
      .subscribe(
        (res: any) => {
          if (res.results) {
            this.counselor = res.results;
          }
        },
        (error: any) => {
          this.api.showToast(error.error.message);
        }
      );
  }
  onEmit(event: any) {
    if (event) {
      let query: any;
      query = `?page=1&page_size=10&counsellor_ids=${event}`;
      this.getLeadlist(query);
    }
  }

  searchTermChanged(event: any) {
    this.searchTerm = event
    let query: any;
    if (event) {
      query = `?page=1&page_size=10&key=${event}`;
    } else {
      query = `?page=1&page_size=10`;
    }
    this.getLeadlist(query);
  }
}
