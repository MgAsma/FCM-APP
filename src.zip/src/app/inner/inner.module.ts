import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InnerPageRoutingModule } from './inner-routing.module';

import { InnerPage } from './inner.page';
import { MaterialModule } from '../shared-modules/material/material/material.module';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InnerPageRoutingModule,
    MaterialModule
  ],
  declarations: [InnerPage],
  
})
export class InnerPageModule {}
