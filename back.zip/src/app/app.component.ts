import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NavController, Platform, ToastController } from '@ionic/angular';
import { App as CapacitorApp } from '@capacitor/app';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(private router:Router,private navCtrl:NavController,private platform: Platform,private toaster:ToastController) {
let token = localStorage.getItem('token');
if(token){
  this.navCtrl.navigateRoot("/inner")
}
else{
  this.navCtrl.navigateRoot("/outer/login")

}

  }

  currentUrl:any
  backbuttonEvent:any
    const =  CapacitorApp.addListener('backButton', async ({canGoBack}) => {
      this.currentUrl=this.router.url;
      this.platform.backButton.observers.pop();
      if(this.currentUrl === '/inner/home') {
        if(canGoBack){
          if(this.backbuttonEvent===0){
            this.backbuttonEvent++;
            let toast = this.toaster.create({
              message: 'Press back again to exit App',
              duration: 5000,
              position: 'bottom','cssClass':'toaster'
              });
              (await toast).present();
              setTimeout(() => {
                this.backbuttonEvent=0;
              }, 5000);
              }else{
                this.backbuttonEvent=0;
                CapacitorApp.exitApp();
              }
          }else {
            if(this.backbuttonEvent===0){
              this.backbuttonEvent++;
              let toast = this.toaster.create({
                message: 'Press back again to exit App',
                duration: 5000,
                position: 'bottom','cssClass':'toaster'
                });
                (await toast).present();
                setTimeout(() => {
                  this.backbuttonEvent=0;
                }, 5000);
                }else{
                  this.backbuttonEvent=0;
                  CapacitorApp.exitApp();
                }
          }
        }
        
       
    });
}
