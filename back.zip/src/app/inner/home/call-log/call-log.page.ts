import { Component, OnInit } from '@angular/core';
import { ModalController, Platform, PopoverController } from '@ionic/angular';
import { AllocationEmittersService } from 'src/app/service/allocation-emitters.service';
import { RecurringFollowupComponent } from '../recurring-followup/recurring-followup.component';
import { GotoViewCustomerDetailsCallCustomerComponent } from '../goto-view-customer-details-call-customer/goto-view-customer-details-call-customer.component';
import { BaseServiceService } from 'src/app/service/base-service.service';
import { environment } from 'src/environments/environment';
import { ApiService } from 'src/app/service/api/api.service';
@Component({
  selector: 'app-call-log',
  templateUrl: './call-log.page.html',
  styleUrls: ['./call-log.page.scss'],
})
export class CallLogPage implements OnInit {
  searchBar: boolean = false;
  filterByStatus:any = []
  data:any = []
  user_role:any;
  user_id:any;
  constructor(
    private allocate: AllocationEmittersService,
    private modalController: ModalController,
    private popoverController: PopoverController,
    private baseService:BaseServiceService,
    private api:ApiService
  ) {
    this.user_role = localStorage.getItem('user_role')?.toUpperCase()
    this.user_id = localStorage.getItem('user_id')
  }

  ngOnInit() {
   
    this.allocate.searchBar.subscribe((res) => {
      if (res === true) {
        this.searchBar = true;
      } else {
        this.searchBar = false;
      }
    });
    let query:any;
  
    this.allocate.filterStatus.subscribe((res:any)=>{
      if(res){
        query = `?counsellor_id=658&status=${res || undefined}`
        this.getCallLogs(query)
      }
    },((error:any)=>{
      this.api.showToast(error.error.message)
    }))
    query = `?counsellor_id=658`
    this.getCallLogs(query)
  }
 
  handleRefresh(event:any) {
    setTimeout(() => {
      // this.leadCards = []
      this.data = []
      let query = `?page=1&page_size=10`
      this.getCallLogs(query)
      event.target.complete();
    }, 2000);
  }
  goBack() {
    window.history.back();
  }
  async openGotoCallOrDetails() {
    const popover = await this.popoverController.create({
      component: GotoViewCustomerDetailsCallCustomerComponent,
      translucent: true,
      backdropDismiss: false,
    });
    return await popover.present();
  }
  getCallLogs(query:any){
    
    
    this.baseService.getData(`${environment.call_logs}/${query}`).subscribe((res:any)=>{
      if(res){
        this.data = res.results
        this.filterByStatus = this.getUniqueCallStatus(this.data);
      }
    },((error:any)=>{
      this.api.showToast(error?.error.message)
    }))
  }
  getUniqueCallStatus(results: any[]): string[] {
    const uniqueCallStatus = results
      .map(result => result.call_status)
      .filter((value, index, self) => self.indexOf(value) === index);

    return uniqueCallStatus;
  }
  onEmit(event:any){
    if(event){
    
      let params:any;
      if(this.user_role == 'SUPERADMIN' || this.user_role == 'SUPER_ADMIN' || this.user_role == 'ADMIN'){
         params = `page=1&page_size=10`
      }else{
         params = `?counsellor_id=658&page=1&page_size=10&status=${event}`
      }
      this.getCallLogs(params)
    } 

  }
}
