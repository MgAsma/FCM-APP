import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HomePageRoutingModule } from './home-routing.module';

import { HomePage } from './home.page';
import { FilterComponent } from './filter/filter.component';
import { InboundComponent } from './inbound/inbound.component';
import { OutboundComponent } from './outbound/outbound.component';
import { TimeListComponent } from './time-list/time-list.component';
import { StatusComponent } from './status/status.component';
import { MaterialModule } from 'src/app/shared-modules/material/material/material.module';
import { OpenFollowupsComponent } from './open-followups/open-followups.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { StartBreakComponent } from './start-break/start-break.component';
import { GotoViewCustomerDetailsCallCustomerComponent } from './goto-view-customer-details-call-customer/goto-view-customer-details-call-customer.component';
import { FollowUpsComponent } from './follow-ups/follow-ups.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HomePageRoutingModule,
    MaterialModule
  ],
  declarations: [HomePage,FilterComponent,InboundComponent,
    OutboundComponent,TimeListComponent,StatusComponent,OpenFollowupsComponent, CheckoutComponent,StartBreakComponent,GotoViewCustomerDetailsCallCustomerComponent,
  FollowUpsComponent]
})
export class HomePageModule {}
