import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddLeadPageRoutingModule } from './add-lead-routing.module';

import { AddLeadPage } from './add-lead.page';
import { MaterialModule } from 'src/app/shared-modules/material/material/material.module';
import { MatFormFieldModule } from '@angular/material/form-field';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    FormsModule,
    ReactiveFormsModule,
    AddLeadPageRoutingModule,
    MaterialModule,
    MatFormFieldModule,
    MatFormFieldModule
  ],
  declarations: [AddLeadPage]
})
export class AddLeadPageModule {}
