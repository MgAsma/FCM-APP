import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToolbarTopComponent } from '../../toolbar-top/toolbar-top.component';
import { IonicModule} from '@ionic/angular';
import { SearchBarComponent } from '../../search-bar/search-bar.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToolbarCustomerComponent } from '../../../toolbar-customer/toolbar-customer.component';
import { FilterComponent } from '../../filter/filter.component';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatCardModule} from '@angular/material/card';
import {MatSelectModule} from '@angular/material/select';
import {MatNativeDateModule} from '@angular/material/core';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {CustomerDetailsComponent } from '../../customer-details/customer-details.component';
import {LeadrecurringFollowupComponent } from '../../leadrecurring-followup/leadrecurring-followup.component';
import {MatPaginatorModule } from '@angular/material/paginator';
import {MatListModule} from '@angular/material/list';
import {OnBreakComponent } from '../../on-break/on-break.component';
import {NodataComponent } from '../../nodata/nodata.component';
import {FormSpaceDirective } from '../../form-space.directive';

@NgModule({
  declarations: [
    ToolbarTopComponent,
    SearchBarComponent,
    ToolbarCustomerComponent,
    FilterComponent,
    CustomerDetailsComponent,
    LeadrecurringFollowupComponent,
    OnBreakComponent,
    NodataComponent,
    FormSpaceDirective
  ],
  imports: [
    CommonModule,
    MatInputModule,
    IonicModule.forRoot(),
    MatExpansionModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatCardModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatPaginatorModule,
    FormsModule,
    ReactiveFormsModule,
    MatListModule
  ],
  exports:[
    MatInputModule,
    ToolbarTopComponent,
    SearchBarComponent,
    FormsModule,
    ReactiveFormsModule,
    ToolbarCustomerComponent,
    FilterComponent,
    MatExpansionModule,
    MatIconModule,
    MatFormFieldModule,
    MatButtonModule,
    MatDatepickerModule,
    MatSelectModule,
    MatNativeDateModule,
    FormsModule,ReactiveFormsModule,
    MatSlideToggleModule,
    CustomerDetailsComponent,
    LeadrecurringFollowupComponent,
    MatPaginatorModule,
    MatListModule,
    OnBreakComponent,
    NodataComponent,
    FormSpaceDirective
  ],
  
})
export class MaterialModule { }
