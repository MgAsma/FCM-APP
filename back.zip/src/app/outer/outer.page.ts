import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outer',
  templateUrl: './outer.page.html',
  styleUrls: ['./outer.page.scss'],
})
export class OuterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
