import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OuterPage } from './outer.page';

describe('OuterPage', () => {
  let component: OuterPage;
  let fixture: ComponentFixture<OuterPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(OuterPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
